# 🏠 Task 2: House Price Prediction
**Alfido Tech Internship | Zainab Ansari**  
GitHub: [github.com/zainabanari2006](https://github.com/zainabanari2006)

---

## 📌 Goal
Build a regression model to predict house prices. Focus on feature engineering,
handling missing values, and model selection.

## 📂 Dataset
[Kaggle – House Price Prediction Dataset](https://www.kaggle.com/datasets/bhanupratapbiswas/house-price-prediction)

---

## 🧠 Models Trained
| Model | RMSE | R² Score |
|-------|:----:|:--------:|
| Linear Regression | - | - |
| Random Forest | - | - |
| Gradient Boosting | - | - |

*(Results filled after running the script)*

---

## 📁 Files
| File | Description |
|------|-------------|
| `house_price_prediction.py` | Full pipeline: EDA → Train → Evaluate → Save |
| `house_prices.csv` | Dataset |
| `best_house_price_model.joblib` | Saved best model |
| `scaler_house.joblib` | Fitted StandardScaler |
| `plot_*.png` | All EDA and evaluation plots |

---

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install numpy pandas matplotlib seaborn scikit-learn joblib
```

### 2. Download dataset
Download CSV from Kaggle and place it in this folder as `house_prices.csv`

### 3. Run the script
```bash
python house_price_prediction.py
```

---

## 🔍 Inference Example
```python
import numpy as np
import joblib
import pandas as pd

model  = joblib.load("best_house_price_model.joblib")
scaler = joblib.load("scaler_house.joblib")

# Provide feature values as a dataframe row
sample = pd.DataFrame([your_feature_values])
prediction = np.expm1(model.predict(scaler.transform(sample)))
print("Predicted Price: $", round(prediction[0], 2))
```

---

## 📊 Plots Generated
- `plot_price_distribution.png` — House price distribution
- `plot_log_price_distribution.png` — Log-transformed price
- `plot_heatmap.png` — Feature correlation heatmap
- `plot_correlation_with_price.png` — Feature correlations with price
- `plot_residuals.png` — Residual analysis for all models
- `plot_actual_vs_predicted.png` — Actual vs predicted prices
- `plot_model_comparison.png` — R² and RMSE comparison
- `plot_feature_importance.png` — Top 15 important features

---

*Submitted as part of Alfido Tech ML Internship — June 2026*
